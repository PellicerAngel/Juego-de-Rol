package Inici;

import Altres.Poder;
import Teclat.Teclat;
import java.util.ArrayList;

public class Poders {

    static ArrayList<Poder> llistaPoders = new ArrayList();

    public static void menuPoders() {
        int opcio = 69;

        while (opcio != 0) {
            opcio = Teclat.lligOpcio("PODERS", "Crear", "Consultar", "Eliminar");

            switch (opcio) {
                case 1:
                    crearPoder();
                    break;

                case 2:
                    consultarPoder();
                    break;

                case 3:
                    eliminarPoder();
                    break;

            }
        }
    }

    public static void crearPoder() {
        String nomPoderCrear = Teclat.lligString("Disme el nom del poder  que vols crear");
        int bonusAtac = Teclat.lligInt("Disme el bonus d'atac que vols que done el poder");
        int bonusDefensa = Teclat.lligInt("Disme el bonus de defensa que vols que done el poder");

        if (llistaPoders.contains(nomPoderCrear)) {
            System.out.println("No se ha pogut crear el poder " + nomPoderCrear + " perque ja existix");

        } else {
            Poder poderCreat = new Poder(nomPoderCrear, bonusAtac, bonusDefensa);
            System.out.println("El poder " + nomPoderCrear + " se ha creat de forma correcta");
            llistaPoders.add(poderCreat);

        }
    }

    public static void consultarPoder() {
//        for (int i = 0; i < llistaPoders.size(); i++) {
//            System.out.println(llistaPoders.get(i).toString());
//
//        } 
        for (Poder poder : llistaPoders) {
            System.out.println(poder);
        }
        System.out.println("");
    }

    
    //EL ELIMINAR NO FUNCIONA
    public static void eliminarPoder() {
        String nomPoderAEliminar = Teclat.lligString("Disme el nom del poder a eliminar");
        Poder poderAEliminar = new Poder(nomPoderAEliminar, 0, 0);

        if (llistaPoders.contains(poderAEliminar)) {

            llistaPoders.remove(poderAEliminar);
            System.out.println("");
            System.out.println("El poder se ha esborrat correctament");

        } else {
            System.out.println("");
            System.out.println("El poder "+nomPoderAEliminar+"  no eixitix. Consulta i intentau novament");

        }

    }

}


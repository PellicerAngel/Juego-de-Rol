package Personatges;

public class Alien extends Jugador {

    // Punt 3,4,11
    public Alien(String nom, int puntsAtac, int puntsDefensa, int vides) {
        super(nom, puntsAtac, puntsDefensa, videsInicials);
        //System.out.println("Soc el constructor de Alien pero estic creant un " + this.getClass().getSimpleName());
    }

    @Override
    public void ataca(Jugador j) {
        System.out.println("ABANS DE L'ATAC :");
        System.out.println("------------------");
        System.out.println("Atacant " + this.toString());
        System.out.println("Defensor " + j.toString());
        System.out.println("");
        System.out.println("ATAC :");
        System.out.println("------------------");

        if (this.getVides() > 20) {

            this.setP_atac(this.getP_atac() + 3);
            this.setP_defensa(this.getP_defensa() - 3);
        }

        this.esColpejatAmb(j.getP_atac());

        j.esColpejatAmb(this.getP_atac());

        System.out.println(
                "");
        System.out.println(
                "DESPRES DE L'ATAC :");
        System.out.println(
                "------------------");
        System.out.println(
                "Atacant " + this.toString());
        System.out.println(
                "Defensor " + j.toString());
    }
}

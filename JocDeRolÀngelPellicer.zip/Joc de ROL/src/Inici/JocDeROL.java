package Inici;

import Altres.Equip;
import Altres.Poder;
import static Inici.Equips.llistaEquips;
import static Inici.Jugadors.llista;
import static Inici.Poders.llistaPoders;
import Teclat.*;
import Personatges.Alien;
import Personatges.Guerrer;
import Personatges.Huma;
import Personatges.Jugador;
import static java.lang.System.exit;

public class JocDeROL {

    // Punt 2
    public static void provaFase1() {

        System.out.println("Vaig a crear un jugador");
        Jugador prova_jugador = new Jugador("pep", 10, 5, 20);

        System.out.println("Vaig a crear un Alien");
        Alien prova_alien = new Alien("juan", 15, 6, 20);

        System.out.println("Vaig a crear un Huma");
        Huma prova_huma = new Huma("marc", 10, 5, 5);

        System.out.println("Vaig a crear un Guerrer");
        Guerrer prova_guerrer = new Guerrer("àngel", 10, 5, 20);
    }

    // Punt 10
    public static void provaFase2() {

        Jugador jug = new Jugador("juan", 10, 2, 20);

        Alien jug_alien = new Alien("pablo", 5, 2, 20);

        Huma jug_huma = new Huma("ang", 15, 6, 20);

        Guerrer jug_gerrer = new Guerrer("juan", 12, 2, 30);

        jug_gerrer.ataca(jug_huma);

    }

    public static void provaFase3() {
        Jugador jug = new Jugador("jug", 6, 2, 20);

        Alien jug_alien = new Alien("ali", 10, 4, 30);

        Huma jug_huma = new Huma("hum", 12, 2, 20);

        Guerrer jug_gerrer = new Guerrer("guerr", 10, 2, 30);

        jug_alien.ataca(jug_huma);
        jug.ataca(jug_gerrer);
    }

    public static void provaFase4() {

        Jugador j = new Jugador("peo", 10, 2, 30);
        Jugador e = new Jugador("juan", 15, 4, 20);
        Equip equip = new Equip("equip");

        System.out.println(j);
        j.setEquip(equip);
        System.out.println(j);
        j.ataca(e);

    }

    public static void provaFase5() {
        Poder p = new Poder("wow", 1, 2);
        Jugador o = new Jugador("o", 10, 2, 30);
        Jugador e = new Jugador("juan", 15, 4, 20);

        o.posa(p);
        System.out.println(o.toString());
        o.ataca(e);
    }

    public static void menuInici() {
        Jugador o = new Jugador("igo", 100, 2, 0);
        Jugador j = new Jugador("juan", 15, 4, 0);
        Poder p = new Poder("op", 105, 0);
        Equip e = new Equip("oli");
        llista.add(o);
        llista.add(j);
        llistaEquips.add(e);
        llistaPoders.add(p);
        o.posa(p);

        int opcio = 69;
        while (opcio != 0) {
            opcio = Teclat.lligOpcio("JOC DE ROL", "Configuració", "Jugar");
            switch (opcio) {
                case 1:
                    menuConfiguracio();
                    break;
                case 2:
                    jugarManual();
                    opcio = 0;
                    break;
            }

        }
    }

    public static void menuConfiguracio() {
        int opcioConfiguracio = 69;
        while (opcioConfiguracio != 0) {
            opcioConfiguracio = Teclat.lligOpcio("CONFIGURACIÓ", "Jugadors", "Equips", "Poders");
            switch (opcioConfiguracio) {
                case 1:
                    Jugadors.menu();

                    break;
                case 2:
                    Equips.menuEquips();

                    break;
                case 3:
                    Poders.menuPoders();

                    break;

            }
        }
    }

    public static void jugarManual() {

        while (llista.size() > 1) {

            for (int i = 0; i < llista.size(); i++) {
                System.out.println("");
                String nomJugadorAAtacar = Teclat.lligString("Jugador " + llista.get(i).getNom() + " disme el nom del jugador que vols atacar");
                System.out.println("");
                Jugador jugadorABuscar = new Jugador(nomJugadorAAtacar, 0, 0, 0);

                int indexOfDeJugador = llista.indexOf(jugadorABuscar);
                Jugador jugadorAtacar = llista.get(indexOfDeJugador);

                if (llista.contains(jugadorABuscar)) {
                    llista.get(i).ataca(jugadorAtacar);
                    if (llista.get(i).getVides() == 0) {
                        llista.remove(i);

                    } else if (jugadorAtacar.getVides() == 0) {
                        llista.remove(jugadorAtacar);
                    }

                } else {
                    System.out.println("El jugador que vols atacar no existix");

                }
            }
        }
        if (llista.size() == 1) {
            System.out.println("");
            System.out.println("El guannyador de la partida es " + llista.get(0).getNom() + " enorabona");

        } else if (llista.size() == 0) {
            System.out.println("");
            System.out.println("Ups, pareix que no queda ningu viu, aixina que no tenim cap guanyador");
        }

    }

    public static void main(String[] args) {
        System.out.println("Benvingut al Joc de Rol");
        menuInici();
        System.out.println("");
        System.out.println("Adeu, espere que hages disfrutat del joc");
        System.out.println("");
        System.out.println("-Àngel Pellicer Grau");
    }

}

package Inici;

import Altres.Equip;
import Teclat.Teclat;
import java.util.ArrayList;

public class Equips {

    static ArrayList<Equip> llistaEquips = new ArrayList();

    public static void menuEquips() {
        int opcio = 69;

        while (opcio != 0) {
            opcio = Teclat.lligOpcio("EQUIPS", "Crear", "Consultar", "Eliminar");

            switch (opcio) {
                case 1:
                    crearEquip();
                    break;

                case 2:
                    consultarEquip();
                    break;

                case 3:
                    eliminarEquip();
                    break;

            }
        }
    }

    public static void crearEquip() {
        String nomEquipCrear = Teclat.lligString("Disme el nom que vols que tinga l'equip");
        System.out.println("");

        if (llistaEquips.contains(nomEquipCrear)) {
            System.out.println("No se ha pogut crear l'equip " + nomEquipCrear + " perque ja existix");

        } else {
            Equip equipCreat = new Equip(nomEquipCrear);
            System.out.println("L'equip " + nomEquipCrear + " se ha creat de forma correcta");
            llistaEquips.add(equipCreat);

        }
    }

    public static void consultarEquip() {
//        for (int i = 0; i < llistaEquips.size(); i++) {
//            System.out.println(llistaEquips.get(i).toString());
//
//        }
        for (Equip equip : llistaEquips) {
            System.out.println(equip);
            
        }
        System.out.println("");
    }

    
    //eL ELIMINAR NO FUNCIONA
    public static void eliminarEquip() {
        String nomEquipAEliminar = Teclat.lligString("Disme el nom de l'equip a eliminar");
        Equip equipAEliminar = new Equip(nomEquipAEliminar);

        if (llistaEquips.contains(equipAEliminar)) {

            llistaEquips.remove(equipAEliminar);
            System.out.println("L'equip se ha esborrat correctament");

        } else {
            System.out.println("L'equip "+nomEquipAEliminar+" no eixitix. Consulta i intentau novament");

        }
    }
}

package Altres;

import Personatges.Jugador;
import java.util.ArrayList;
import java.util.Objects;

public class Equip {

    private String nom;
    ArrayList <Jugador> jugadors = new ArrayList();
    

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Equip(String nom) {
        this.nom = nom;
    }     

    
    public void posa(Jugador j) {
        if (!jugadors.contains(j)) {
            jugadors.add(j);
            j.setEquip(this);
        }
    }

    public void lleva(String nomJugador) {
        Jugador j = new Jugador(nomJugador, 1, 1, 1);
        jugadors.remove(j);
        j.setEquip(null);
    }

    @Override
    public int hashCode() {
        int hash = 5;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Equip other = (Equip) obj;
        return Objects.equals(this.nom, other.nom);
    }

    
    @Override
    public String toString() {
        String mostrar = "Equip " + this.getNom() + " : \n";

        for (Jugador j : jugadors) {
            mostrar += "- " + j.toString() + "\n";     
        }
        return mostrar;

    }

}

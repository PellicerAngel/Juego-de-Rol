package Personatges;

import Altres.Equip;
import Altres.Poder;
import java.util.Objects;
import Altres.*;
import java.util.ArrayList;

public class Jugador {

    // Punt 4
    private String nom;
    private int puntsAtac;
    private int puntsDefensa;
    private int vides;
    private Equip equip;
    ArrayList<Poder> poders = new ArrayList();
    static int videsInicials = 200;

    // Punt 3 i 5
    public Jugador(String nom, int puntsAtac, int puntsDefensa, int vides) {
        this.nom = nom;
        this.puntsAtac = puntsAtac;
        this.puntsDefensa = puntsDefensa;
        this.vides = videsInicials;
        //System.out.println("Soc el constructor de Jugador pero estic creant un " + this.getClass().getSimpleName());
    }

    // Punt 6
    public String getNom() {
        return nom;
    }

    protected void setNom(String nom) {
        this.nom = nom;
    }

    public int getP_atac() {
        return puntsAtac;
    }

    protected void setP_atac(int p_atac) {
        this.puntsAtac = p_atac;
    }

    public int getP_defensa() {
        return puntsDefensa;
    }

    protected void setP_defensa(int p_defensa) {
        this.puntsDefensa = p_defensa;
    }

    public int getVides() {
        return vides;
    }

    protected void setVides(int vides) {
        this.vides = vides;
    }

    // Punt 7
    @Override
    public String toString() {
        String equip;

        if (this.getEquip() == null) {
            equip = "No te equip";
        } else {
            equip = this.getEquip().getNom();
        }
            String cadena = null;

        if (this.poders.size() < 1) {
            cadena = "";
        } else {
            cadena = " te els poders: \n";
            for (Poder poder : poders) {
                cadena += "- " + poder.toString() + "\n";
            }
        }

        return nom + " [" + equip + "]" + "( " + this.getClass().getSimpleName() + ", PA:"
                + puntsAtac + ", PD:" + puntsDefensa + ", PV:" + vides + ")" + cadena;
    }

    // Punt 8
    protected void esColpejatAmb(int numPuntsAtac) {
        int bonusDefensaPoders = 0;
//        int bonusAtacPoders = 0;
        int vidaInicial = this.vides;

        for (int i = 0; i < this.poders.size(); i++) {

            bonusDefensaPoders += this.poders.get(i).getBonusDefensa();
//            bonusAtacPoders += this.poders.get(i).getBonusAtac();
        }

        int ferida = numPuntsAtac - (this.puntsDefensa + bonusDefensaPoders);
        this.vides -= ferida;

        if (this.vides < 0) {
            this.vides = 0;
            System.out.println("El atacat te menys de 0 vides");
        }

        System.out.println(this.nom + " és colpejat amb " + numPuntsAtac + " punts i és defén amb " + (this.puntsDefensa + bonusDefensaPoders)
                + ". Vides: " + vidaInicial + " - " + ferida + " = " + this.vides);

    }

    // Punt 9
    // Modificar 
    public void ataca(Jugador j) {

        int bonusAtacPoders = 0;

        System.out.println("ABANS DE L'ATAC :");
        System.out.println("------------------");
        System.out.println("Atacant " + this.toString());
        System.out.println(this.poders.toString());
        System.out.println("Defensor " + j.toString());
        System.out.println(j.poders.toString());

        System.out.println("");
        System.out.println("ATAC :");
        System.out.println("------------------");

        //Problema per el cual els punts d'atac es 0
        for (int i = 0; i < j.poders.size(); i++) {

            bonusAtacPoders += j.poders.get(i).getBonusAtac();

        }

        this.esColpejatAmb(j.getP_atac() + bonusAtacPoders);

        bonusAtacPoders = 0;

        for (int i = 0; i < this.poders.size(); i++) {

            bonusAtacPoders += this.poders.get(i).getBonusAtac();

        }

        j.esColpejatAmb(this.getP_atac() + bonusAtacPoders);

        System.out.println("");

        System.out.println("DESPRES DE L'ATAC :");
        System.out.println("------------------");
        System.out.println("Atacant " + this.toString());
        System.out.println("Defensor " + j.toString());

    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Jugador other = (Jugador) obj;
        return Objects.equals(this.nom, other.nom);
    }

    public Equip getEquip() {
        return equip;
    }

    public void setEquip(Equip equip) {

        if (equip == null) {

            equip.lleva(this.getNom());
            this.equip = null;

        } else {

            this.equip = equip;
            equip.posa(this);

        }
    }

    // Fer que pose un poder
    public void posa(Poder poder) {

        poders.add(poder);
    }

    // Fer que lleve un poder
    public void lleva(Poder poder) {

        poders.remove(poder);
    }

}

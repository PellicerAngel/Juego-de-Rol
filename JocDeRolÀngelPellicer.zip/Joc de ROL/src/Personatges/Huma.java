package Personatges;

public class Huma extends Jugador {

    // Punt 3,4,11
    public Huma(String nom, int puntsAtac, int puntsDefensa, int vides) {
        super(nom, puntsAtac, puntsDefensa, videsInicials);
        
        //System.out.println("Soc el constructor de Huma pero estic creant un " + this.getClass().getSimpleName());

        if (vides > 100) {
            vides = 100;
        }
    }

}

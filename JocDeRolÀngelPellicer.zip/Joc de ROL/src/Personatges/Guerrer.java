package Personatges;

public class Guerrer extends Huma {

    // Punt 3 i 4
    public Guerrer(String nom, int puntsAtac, int puntsDefensa, int vides) {
        super(nom, puntsAtac, puntsDefensa, videsInicials);
        //System.out.println("Soc el constructor de Guerrer pero estic creant un " + this.getClass().getSimpleName());
    }

    // Modificar el es colpejat amb 
    @Override
    protected void esColpejatAmb(int num_punts_atacats) {
        int ferida = num_punts_atacats - this.getP_defensa();
        int vida_inici = this.getVides();

        if (this instanceof Guerrer) {
            if (ferida <= 5) {
            } else {
                this.setVides(this.getVides() - ferida);
            }
        }

        if (this.getVides() < 0) {
            this.setVides(0);
            System.out.println("El atacat te menys de 0 vides");
        }

        System.out.println(this.getNom() + " és colpejat amb " + num_punts_atacats + " punts i és defén amb " + this.getP_defensa()
                + ". Vides: " + vida_inici + " - " + ferida + " = " + this.getVides());

    }

}

package Inici;

import Altres.Equip;
import Altres.Poder;
import static Inici.Equips.llistaEquips;
import static Inici.Poders.llistaPoders;
import Personatges.Alien;
import Personatges.Guerrer;
import Personatges.Huma;
import Personatges.Jugador;
import Teclat.Teclat;
import java.util.ArrayList;

public class Jugadors {

    static ArrayList<Jugador> llista = new ArrayList();

    public static void menu() {
        int opcio = 69;

        while (opcio != 0) {
            opcio = Teclat.lligOpcio("JUGADORS", "Crear", "Consultar", "Eliminar", "Assignar a equipo",
                    "Llevar d'equip", "Assignar poder");

            switch (opcio) {

                case 1:
                    crear();

                    break;

                case 2:
                    consultar();

                    break;

                case 3:
                    eliminar();

                    break;

                case 4:
                    assignarEquip();

                    break;

                case 5:
                    assignarEquip();
                    break;

                case 6:
                    assignarPoder();
                    break;

            }

        }
    }

    public static void crear() {
        char TipusJugadorACrear = Teclat.lligChar("Tipus de jugador ", "HGA");
        String nomDelJugador = Teclat.lligString("Nom de Jugador");
        int PuntsAtac = Teclat.lligInt("Punts d'atac", 1, 100);
        int PuntsDefensa = 100 - PuntsAtac;
        Jugador jugadorEsPotCrear = new Jugador(nomDelJugador, 0, 0, 0);
        Jugador j = null;
        if (llista.contains(jugadorEsPotCrear)) {
            System.out.println("El Jugador " + nomDelJugador + " ja existix ");

        } else {
            switch (TipusJugadorACrear) {

                case 'H':
                    
                    j = new Huma(nomDelJugador, PuntsAtac, PuntsDefensa, 0);
                    break;
                case 'G':
                    j = new Guerrer(nomDelJugador, PuntsAtac, PuntsDefensa, 0);
                    break;
                case 'A':
                    j= new Alien(nomDelJugador, PuntsAtac, PuntsDefensa, 0);
                    break;
                default:
                    break;
            }
            llista.add(j);
        }
    }

    public static void consultar() {
//        for (int i = 0; i < llista.size(); i++) {
//            System.out.println(llista.get(i).toString());
//
//        }
        for (Jugador jugador : llista) {
            System.out.println(jugador);
            
        }
        System.out.println("");          
        
    }

    //no funciona
    public static void eliminar() {
        String nomJugadorAEliminar = Teclat.lligString("Disme el nom del jugador a eliminar");
        Jugador jugadorAEliminar = new Jugador(nomJugadorAEliminar, 0, 0, 0);

        if (llista.contains(jugadorAEliminar)) {

            llista.remove(jugadorAEliminar);
            System.out.println("El jugador se ha esborrat correctament");

        } else {
            System.out.println("El jugador " + nomJugadorAEliminar + " no eixitix. Consulta i intentau novament");

        }
    }

    //No funciona
    public static void assignarEquip() {
        String nomJugadorABuscar = Teclat.lligString("Disme el nom del jugador per a assignar");
        Jugador jugadorABuscar = new Jugador(nomJugadorABuscar, 0, 0, 0);
        int indexOfDeJugador = llista.indexOf(jugadorABuscar);
        System.out.println("");

        if (indexOfDeJugador >= 0) {
            String nomEquipAssignar = Teclat.lligString("Disme el nom del equip al que el vols afegir");
            Equip equipVolemAssignar = new Equip(nomEquipAssignar);
            int indexOfDeEquip = llistaEquips.indexOf(equipVolemAssignar);

            if (indexOfDeEquip >= 0) {
                Equip equipObtingut = llistaEquips.get(indexOfDeEquip);
                Jugador jugadorObtingut = llista.get(indexOfDeJugador);

                equipObtingut.posa(jugadorObtingut);

                System.out.println("El jugador " + nomJugadorABuscar + " se ha afegit correctament a l'equip " + nomEquipAssignar);

            } else {
                System.out.println("L'equip " + nomEquipAssignar + " no existix");
            }
        } else {

            System.out.println("El jugador " + nomJugadorABuscar + " no existix");

        }
    }

    public static void assignarPoder() {
        String nomJugadorABuscar = Teclat.lligString("Disme el nom del jugador per a assignar");
        Jugador jugadorABuscar = new Jugador(nomJugadorABuscar, 0, 0, 0);
        int indexOfDeJugador = llista.indexOf(jugadorABuscar);
        System.out.println("");

        if (indexOfDeJugador >= 0) {
            String nomPoderAssignar = Teclat.lligString("Disme el nom del poder que vols afegir");
            Poder poderAssignar = new Poder(nomPoderAssignar, 0, 0);
            int indexOfDePoder = llistaPoders.indexOf(poderAssignar);

            if (indexOfDePoder >= 0) {
                Jugador jugadorObtingut = llista.get(indexOfDeJugador);
                Poder poderObtingut = llistaPoders.get(indexOfDePoder);

                jugadorObtingut.posa(poderObtingut);
                System.out.println("Se ha afegit correctament el poder " + nomPoderAssignar + " al jugador " + nomJugadorABuscar);

            } else {
                System.out.println("El poder " + nomPoderAssignar + " no existix");

            }

        } else {
            System.out.println("El jugador " + nomJugadorABuscar + " indicat no existix");

        }
    }

}
